-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 23, 2024 at 07:02 PM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `city_game_copy`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer_text` text NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`id`, `question_id`, `answer_text`, `is_correct`) VALUES
(1, 1, 'Done', 1),
(2, 1, 'Not done', 0),
(3, 1, 'Not done', 0),
(4, 2, 'XD cafe', 1),
(5, 2, 'Allumni evening XD and IDPA', 0),
(6, 2, 'Old meets young', 0),
(7, 3, 'Buffalo\'s', 0),
(8, 3, 'Manenblussers', 1),
(9, 3, 'Malinois', 0),
(10, 4, 'A pigeon', 1),
(11, 4, 'An eagle', 0),
(12, 4, 'A pelican', 0),
(13, 5, 'A bull', 1),
(14, 5, 'A horse', 0),
(15, 5, 'A ram', 0),
(16, 6, 'Vrijbroekspark', 0),
(17, 6, 'Tivoli Park', 0),
(18, 6, 'Kruidtuin', 1),
(19, 7, 'Linde', 1),
(20, 7, 'David', 0),
(21, 7, 'An AI tool', 0),
(22, 8, 'Duhoux', 0),
(23, 8, 'Dzia', 1),
(24, 8, 'Unknown', 0),
(25, 9, 'XDtreme', 0),
(26, 9, 'XDtravaganza\r\n', 1),
(27, 9, 'XD & IDPA party', 0),
(28, 10, 'Bottle opener and hairpin', 0),
(29, 10, 'Bottle opener and clothespin', 1),
(30, 10, 'Clothespin and corkscrew', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fellow`
--

CREATE TABLE `fellow` (
  `id` int(11) NOT NULL,
  `fellow_group_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fellow`
--

INSERT INTO `fellow` (`id`, `fellow_group_id`, `full_name`) VALUES
(1, 1, 'John Doe'),
(2, 1, 'Stijn Houwelijckx');

-- --------------------------------------------------------

--
-- Table structure for table `fellow_group`
--

CREATE TABLE `fellow_group` (
  `id` int(11) NOT NULL,
  `groupname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fellow_group`
--

INSERT INTO `fellow_group` (`id`, `groupname`) VALUES
(1, 'Example Group');

-- --------------------------------------------------------

--
-- Table structure for table `group_answer`
--

CREATE TABLE `group_answer` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `answer_id` int(11) NOT NULL,
  `answer_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group_answer`
--

INSERT INTO `group_answer` (`id`, `group_id`, `answer_id`, `answer_time`) VALUES
(1, 1, 8, '2024-02-23 20:01:21'),
(2, 1, 11, '2024-02-23 20:01:45');

-- --------------------------------------------------------

--
-- Table structure for table `group_progress`
--

CREATE TABLE `group_progress` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `current_question_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group_progress`
--

INSERT INTO `group_progress` (`id`, `group_id`, `current_question_id`) VALUES
(1, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `question_text` text NOT NULL,
  `code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `quiz_id`, `question_text`, `code`) VALUES
(1, 1, 'Take a funny group picture, share it on Instagram and tag @wearexd', '3347'),
(2, 1, 'What is that evening called?', '5078'),
(3, 1, 'What are the people of Mechelen called?', '4147'),
(4, 1, 'What is the animal on this statue?', '2649'),
(5, 1, 'To what animal belongs this head?', '7820'),
(6, 1, 'What is this park called?', '6755'),
(7, 1, 'Who is the creator of this logo?', '0478'),
(8, 1, 'Who is the artist behind this mural?', '9732'),
(9, 1, 'What’s the name of our party?', '1864'),
(10, 1, 'What tools are shown in the logo?', '8411');

-- --------------------------------------------------------

--
-- Table structure for table `question_location`
--

CREATE TABLE `question_location` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `latitude` varchar(255) NOT NULL,
  `longitude` varchar(255) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `question_location`
--

INSERT INTO `question_location` (`id`, `question_id`, `latitude`, `longitude`, `image_url`) VALUES
(1, 1, '51.02936877146115', '4.47831373764008', 'assets/locationImages/question-1.jpg'),
(2, 2, '51.0283557532074', '4.480467939571356', 'assets/locationImages/question-2.jpg'),
(3, 3, '51.02805912103554', '4.481088137370971', 'assets/locationImages/question-3.jpg'),
(4, 4, '51.02585901938823', '4.481365096385959', 'assets/locationImages/question-4.jpg'),
(5, 5, '51.02642609923778', '4.484047749988756', 'assets/locationImages/question-5.jpg'),
(6, 6, '51.02355488950256', '4.484243277456023', 'assets/locationImages/question-6.jpg'),
(7, 7, '51.022600876210156', '4.4814571965585435', 'assets/locationImages/question-7.jpg'),
(8, 8, '51.02434039949005', '4.480465373485359', 'assets/locationImages/question-8.jpg'),
(9, 9, '51.0264401694364', '4.476700186525076', 'assets/locationImages/question-9.jpg'),
(10, 10, '51.02707340781768', '4.479077843346591', 'assets/locationImages/question-10.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`id`, `title`) VALUES
(1, 'City Game');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `fellow`
--
ALTER TABLE `fellow`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fellow_group_id` (`fellow_group_id`);

--
-- Indexes for table `fellow_group`
--
ALTER TABLE `fellow_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `group_answer`
--
ALTER TABLE `group_answer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `answer_id` (`answer_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `group_progress`
--
ALTER TABLE `group_progress`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `group_progress_id` (`current_question_id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Indexes for table `question_location`
--
ALTER TABLE `question_location`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answer`
--
ALTER TABLE `answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `fellow`
--
ALTER TABLE `fellow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fellow_group`
--
ALTER TABLE `fellow_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `group_answer`
--
ALTER TABLE `group_answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `group_progress`
--
ALTER TABLE `group_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `question_location`
--
ALTER TABLE `question_location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer`
--
ALTER TABLE `answer`
  ADD CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`);

--
-- Constraints for table `fellow`
--
ALTER TABLE `fellow`
  ADD CONSTRAINT `fellow_ibfk_1` FOREIGN KEY (`fellow_group_id`) REFERENCES `fellow_group` (`id`);

--
-- Constraints for table `group_answer`
--
ALTER TABLE `group_answer`
  ADD CONSTRAINT `group_answer_ibfk_1` FOREIGN KEY (`answer_id`) REFERENCES `answer` (`id`),
  ADD CONSTRAINT `group_answer_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `fellow_group` (`id`);

--
-- Constraints for table `group_progress`
--
ALTER TABLE `group_progress`
  ADD CONSTRAINT `group_id` FOREIGN KEY (`group_id`) REFERENCES `fellow_group` (`id`),
  ADD CONSTRAINT `group_progress_id` FOREIGN KEY (`current_question_id`) REFERENCES `question` (`id`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`id`);

--
-- Constraints for table `question_location`
--
ALTER TABLE `question_location`
  ADD CONSTRAINT `question_location_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
